package top.niunaijun.blackbox.fake.frameworks;

import android.os.IBinder;
import android.os.RemoteException;

import java.util.ArrayList;
import java.util.List;

import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.system.ServiceManager;
import top.niunaijun.blackbox.core.system.location.IBLocationManagerService;
import top.niunaijun.blackbox.entity.location.BCell;
import top.niunaijun.blackbox.entity.location.BLocation;


public class BLocationManager extends BlackManager<IBLocationManagerService> {
    private static final BLocationManager sLocationManager = new BLocationManager();

    public static final int CLOSE_MODE = 0;
    public static final int GLOBAL_MODE = 1;
    public static final int OWN_MODE = 2;

    public static BLocationManager get() {
        return sLocationManager;
    }

    @Override
    protected String getServiceName() {
        return ServiceManager.LOCATION_MANAGER;
    }

    public static boolean isFakeLocationEnable() {
        return get().getPattern(BActivityThread.getUserId(), BActivityThread.getAppPackageName()) != CLOSE_MODE;
    }

    public static void disableFakeLocation(int userId,String pkg){
        get().setPattern(userId,pkg,CLOSE_MODE);
    }

    public void setPattern(int userId, String pkg, int pattern) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setPattern(userId, pkg, pattern);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public int getPattern(int userId, String pkg) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return CLOSE_MODE;
            return service.getPattern(userId, pkg);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return CLOSE_MODE;
    }

    public void setCell(int userId, String pkg, BCell cell) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setCell(userId, pkg, cell);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void setAllCell(int userId, String pkg, List<BCell> cells) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setAllCell(userId, pkg, cells);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public List<BCell> getNeighboringCell(int userId, String pkg) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return null;
            return service.getNeighboringCell(userId, pkg);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<BCell> getGlobalNeighboringCell() {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return null;
            return service.getGlobalNeighboringCell();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setNeighboringCell(int userId, String pkg, List<BCell> cells) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setNeighboringCell(userId, pkg, cells);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void setGlobalCell(BCell cell) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setGlobalCell(cell);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void setGlobalAllCell(List<BCell> cells) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setGlobalAllCell(cells);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void setGlobalNeighboringCell(List<BCell> cells) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setGlobalNeighboringCell(cells);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public BCell getCell(int userId, String pkg) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return null;
            return service.getCell(userId, pkg);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<BCell> getAllCell(int userId, String pkg) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return new ArrayList<>();
            return service.getAllCell(userId, pkg);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    public void setLocation(int userId, String pkg, BLocation location) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setLocation(userId, pkg, location);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public BLocation getLocation(int userId, String pkg) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return null;
            return service.getLocation(userId, pkg);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setGlobalLocation(BLocation location) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.setGlobalLocation(location);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public BLocation getGlobalLocation() {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return null;
            return service.getGlobalLocation();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void requestLocationUpdates(IBinder listener) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.requestLocationUpdates(listener, BActivityThread.getAppPackageName(), BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void removeUpdates(IBinder listener) {
        try {
            IBLocationManagerService service = getService();
            if (service == null) return;
            service.removeUpdates(listener);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
}
