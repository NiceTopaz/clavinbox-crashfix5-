package top.niunaijun.blackbox.fake.frameworks;

import android.accounts.Account;
import android.accounts.AuthenticatorDescription;
import android.accounts.IAccountManagerResponse;
import android.os.Bundle;
import android.os.RemoteException;

import java.util.Map;

import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.system.ServiceManager;
import top.niunaijun.blackbox.core.system.accounts.IBAccountManagerService;


public class BAccountManager extends BlackManager<IBAccountManagerService> {
    private static final BAccountManager sBAccountManager = new BAccountManager();

    public static BAccountManager get() {
        return sBAccountManager;
    }

    @Override
    protected String getServiceName() {
        return ServiceManager.ACCOUNT_MANAGER;
    }

    public String getPassword(Account account) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getPassword(account, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }


    public String getUserData(Account account, String key) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getUserData(account, key, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public AuthenticatorDescription[] getAuthenticatorTypes() {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getAuthenticatorTypes(BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Account[] getAccountsForPackage(String packageName, int uid) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getAccountsForPackage(packageName, uid, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Account[] getAccountsByTypeForPackage(String type, String packageName) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getAccountsByTypeForPackage(type, packageName, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Account[] getAccountsAsUser(String type) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getAccountsAsUser(type, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void getAccountByTypeAndFeatures(IAccountManagerResponse response, String accountType,
                                            String[] features) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.getAccountByTypeAndFeatures(response, accountType, features, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
    
    public void getAccountsByFeatures(IAccountManagerResponse response, String accountType,
                               String[] features) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.getAccountsByFeatures(response, accountType, features, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public boolean addAccountExplicitly(Account account, String password, Bundle extras) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return false;
            return service.addAccountExplicitly(account, password, extras, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void removeAccountAsUser(IAccountManagerResponse response, Account account,
                             boolean expectActivityLaunch) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.removeAccountAsUser(response, account, expectActivityLaunch, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public boolean removeAccountExplicitly(Account account) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return false;
            return service.removeAccountExplicitly(account, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void copyAccountToUser(IAccountManagerResponse response, Account account,
                           int userFrom, int userTo) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.copyAccountToUser(response, account, userFrom, userTo);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void invalidateAuthToken(String accountType, String authToken) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.invalidateAuthToken(accountType, authToken, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public String peekAuthToken(Account account, String authTokenType) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.peekAuthToken(account, authTokenType, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setAuthToken(Account account, String authTokenType, String authToken) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.setAuthToken(account, authTokenType, authToken, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }


    public void setPassword(Account account, String password) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.setPassword(account, password, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void clearPassword(Account account) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.clearPassword(account, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void setUserData(Account account, String key, String value) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.setUserData(account, key, value, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void updateAppPermission(Account account, String authTokenType, int uid, boolean value) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.updateAppPermission(account, authTokenType, uid, value);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void getAuthToken(IAccountManagerResponse response, Account account,
                      String authTokenType, boolean notifyOnAuthFailure, boolean expectActivityLaunch,
                      Bundle options) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.getAuthToken(response, account, authTokenType, notifyOnAuthFailure, expectActivityLaunch, options, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void addAccount(IAccountManagerResponse response, String accountType,
                    String authTokenType, String[] requiredFeatures, boolean expectActivityLaunch,
                    Bundle options) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.addAccount(response, accountType, authTokenType, requiredFeatures, expectActivityLaunch, options, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void addAccountAsUser(IAccountManagerResponse response, String accountType,
                          String authTokenType, String[] requiredFeatures, boolean expectActivityLaunch,
                          Bundle options) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.addAccountAsUser(response, accountType, authTokenType, requiredFeatures, expectActivityLaunch, options, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void updateCredentials(IAccountManagerResponse response, Account account,
                           String authTokenType, boolean expectActivityLaunch, Bundle options) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.updateCredentials(response, account, authTokenType, expectActivityLaunch, options, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void editProperties(IAccountManagerResponse response, String accountType,
                        boolean expectActivityLaunch) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.editProperties(response, accountType, expectActivityLaunch, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void confirmCredentialsAsUser(IAccountManagerResponse response, Account account,
                                  Bundle options, boolean expectActivityLaunch) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.confirmCredentialsAsUser(response, account, options, expectActivityLaunch, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public boolean accountAuthenticated(Account account) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return false;
            return service.accountAuthenticated(account, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void getAuthTokenLabel(IAccountManagerResponse response, String accountType,
                           String authTokenType) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.getAuthTokenLabel(response, accountType, authTokenType, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    
    public Map getPackagesAndVisibilityForAccount(Account account) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getPackagesAndVisibilityForAccount(account, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean addAccountExplicitlyWithVisibility(Account account, String password, Bundle extras,
                                               Map visibility) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return false;
            return service.addAccountExplicitlyWithVisibility(account, password, extras, visibility, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean setAccountVisibility(Account account, String packageName, int newVisibility) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return false;
            return service.setAccountVisibility(account, packageName, newVisibility, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return false;
    }

    public int getAccountVisibility(Account account, String packageName) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getAccountVisibility(account, packageName, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        
        return 3;
    }

    
    public Map getAccountsAndVisibilityForPackage(String packageName, String accountType) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return null;
            return service.getAccountsAndVisibilityForPackage(packageName, accountType, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void registerAccountListener(String[] accountTypes, String opPackageName) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.registerAccountListener(accountTypes, opPackageName, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void unregisterAccountListener(String[] accountTypes, String opPackageName) {
        try {
            IBAccountManagerService service = getService();
            if (service == null) return;
            service.unregisterAccountListener(accountTypes, opPackageName, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
}
