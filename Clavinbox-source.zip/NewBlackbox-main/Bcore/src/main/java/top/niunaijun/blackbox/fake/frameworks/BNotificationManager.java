package top.niunaijun.blackbox.fake.frameworks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.os.RemoteException;

import java.util.ArrayList;
import java.util.List;

import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.system.ServiceManager;
import top.niunaijun.blackbox.core.system.notification.IBNotificationManagerService;


public class BNotificationManager extends BlackManager<IBNotificationManagerService> {
    private static final BNotificationManager sNotificationManager = new BNotificationManager();

    public static BNotificationManager get() {
        return sNotificationManager;
    }

    @Override
    protected String getServiceName() {
        return ServiceManager.NOTIFICATION_MANAGER;
    }

    // getService() returns null whenever the real notification-service binder is
    // momentarily unavailable (recently failed, rate-limited, or dead and not yet
    // reconnected) — a real, documented case in BlackManager, not just a theoretical
    // one. None of the methods below checked for it before calling straight through,
    // which crashed with a NullPointerException the moment that happened (confirmed
    // from an actual crash log). Every method now checks first and returns the same
    // safe default the rest of the engine already uses elsewhere for this situation.

    public NotificationChannel getNotificationChannel(String channelId) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return null;
            return service.getNotificationChannel(channelId, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<NotificationChannelGroup> getNotificationChannelGroups(String packageName) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return null;
            return service.getNotificationChannelGroups(packageName, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void createNotificationChannel(NotificationChannel notificationChannel) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return;
            service.createNotificationChannel(notificationChannel, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void deleteNotificationChannel(String channelId) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return;
            service.deleteNotificationChannel(channelId, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void createNotificationChannelGroup(NotificationChannelGroup notificationChannelGroup) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return;
            service.createNotificationChannelGroup(notificationChannelGroup, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void deleteNotificationChannelGroup(String groupId) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return;
            service.deleteNotificationChannelGroup(groupId, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void enqueueNotificationWithTag(int id, String tag, Notification notification) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return;
            service.enqueueNotificationWithTag(id, tag, notification, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void cancelNotificationWithTag(int id, String tag) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return;
            service.cancelNotificationWithTag(id, tag, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public List<NotificationChannel> getNotificationChannels(String packageName) {
        try {
            IBNotificationManagerService service = getService();
            if (service == null) return new ArrayList<>();
            return service.getNotificationChannels(packageName, BActivityThread.getUserId());
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }
}
